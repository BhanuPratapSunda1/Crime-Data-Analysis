# Regression Template

# Importing the dataset
dataset = read.csv('dataa.csv')
dataset = dataset[,c(1:844,858)]

# Fitting the SVR to the dataset
# Create your regressor here
library(e1071)
regressor = svm(formula = THEFT ~ ., data = dataset, type = 'eps-regression')
# Predicting a new result
#y_pred = predict(regressor, data.frame(YEAR = 2013))

# Visualising the SVR results
# install.packages('ggplot2')
library(ggplot2)
ggplot() +
  geom_point(aes(x = dataset$YEAR, y = dataset$THEFT),
             colour = 'red') +
  geom_line(aes(x = dataset$YEAR, y = predict(regressor, newdata = dataset)),
            colour = 'blue') +
  ggtitle('THEFT Vs.YEAR (SVR Model)') +
  xlab('YEAR') +
  ylab('THEFT')